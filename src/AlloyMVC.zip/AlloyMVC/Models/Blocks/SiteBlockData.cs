namespace AlloyMVC.Models.Blocks;

/// <summary>
/// Base class for all block types on the site
/// </summary>
public abstract class SiteBlockData : BlockData
{
}
