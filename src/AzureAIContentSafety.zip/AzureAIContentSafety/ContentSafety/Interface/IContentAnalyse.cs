﻿namespace AzureAIContentSafety.ContentSafety.Interface
{
    public interface IContentAnalyse
    {
        bool ContentSafetyAnalysisCompleted { get; set; }
    }
}
